#include "BlackHole.h"



BlackHole::BlackHole()
{
}


BlackHole::~BlackHole()
{
}
