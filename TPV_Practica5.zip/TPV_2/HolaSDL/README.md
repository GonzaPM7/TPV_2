Template for students.
