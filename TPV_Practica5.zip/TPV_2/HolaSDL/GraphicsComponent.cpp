#include "GraphicsComponent.h"

GraphicsComponent::GraphicsComponent() {
}

GraphicsComponent::~GraphicsComponent() {
}

