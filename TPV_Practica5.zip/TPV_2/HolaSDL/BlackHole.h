#pragma once
#include "Container.h"
class BlackHole :
	public Container
{
public:
	BlackHole();
	~BlackHole();
};

