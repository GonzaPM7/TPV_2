#include "InputComponent.h"

InputComponent::InputComponent() {
	// TODO Auto-generated constructor stub

}

InputComponent::~InputComponent() {
	// TODO Auto-generated destructor stub
}

