#include "FontsManager.h"

FontsManager::FontsManager() {
	// TODO Auto-generated constructor stub

}

FontsManager::~FontsManager() {
	// TODO Auto-generated destructor stub
}

