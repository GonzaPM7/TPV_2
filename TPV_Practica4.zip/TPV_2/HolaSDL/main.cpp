#include "AsteroidsGame.h"

using namespace std;

int main(int ac, char** av) {

	AsteroidsGame g;
	g.start();
	return 0;
}
